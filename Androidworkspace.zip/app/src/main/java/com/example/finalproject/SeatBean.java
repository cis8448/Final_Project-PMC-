package com.example.finalproject;

public class SeatBean {

    private String p_id;
    private String s_id;
    private String s_state;
    private String s_spec;
    private String s_noreserve;
    private String m_id;
    private String m_time;
    private String m_birthday;
    private String s_name;

    public String getS_name() {
        return s_name;
    }

    public void setS_name(String s_name) {
        this.s_name = s_name;
    }

    public String getP_id() {
        return p_id;
    }

    public void setP_id(String p_id) {
        this.p_id = p_id;
    }

    public String getS_id() {
        return s_id;
    }

    public void setS_id(String s_id) {
        this.s_id = s_id;
    }

    public String getS_state() {
        return s_state;
    }

    public void setS_state(String s_state) {
        this.s_state = s_state;
    }

    public String getS_spec() {
        return s_spec;
    }

    public void setS_spec(String s_spec) {
        this.s_spec = s_spec;
    }

    public String getS_noreserve() {
        return s_noreserve;
    }

    public void setS_noreserve(String s_noreserve) {
        this.s_noreserve = s_noreserve;
    }

    public String getM_id() {
        return m_id;
    }

    public void setM_id(String m_id) {
        this.m_id = m_id;
    }

    public String getM_time() {
        return m_time;
    }

    public void setM_time(String m_time) {
        this.m_time = m_time;
    }

    public String getM_birthday() {
        return m_birthday;
    }

    public void setM_birthday(String m_birthday) {
        this.m_birthday = m_birthday;
    }
}