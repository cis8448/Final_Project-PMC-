package com.example.finalproject;

import com.google.gson.annotations.SerializedName;

public class PictureBean {

    private String Picture1;
    private String Picture2;
    private String Picture3;

    public String getPicture1() {
        return Picture1;
    }

    public void setPicture1(String picture1) {
        Picture1 = picture1;
    }

    public String getPicture2() {
        return Picture2;
    }

    public void setPicture2(String picture2) {
        Picture2 = picture2;
    }

    public String getPicture3() {
        return Picture3;
    }

    public void setPicture3(String picture3) {
        Picture3 = picture3;
    }
}
