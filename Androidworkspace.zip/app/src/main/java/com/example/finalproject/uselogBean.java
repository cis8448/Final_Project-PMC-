package com.example.finalproject;

public class uselogBean {

    private String u_m_id;
    private String u_s_id;
    private String u_code;
    private String u_start;
    private String u_finish;
    private String u_cate;


    public String getU_m_id() {
        return u_m_id;
    }
    public void setU_m_id(String u_m_id) {
        this.u_m_id = u_m_id;
    }
    public String getU_s_id() {
        return u_s_id;
    }
    public void setU_s_id(String u_s_id) {
        this.u_s_id = u_s_id;
    }
    public String getU_code() {
        return u_code;
    }
    public void setU_code(String u_code) {
        this.u_code = u_code;
    }
    public String getU_start() {
        return u_start;
    }
    public void setU_start(String u_start) {
        this.u_start = u_start;
    }
    public String getU_finish() {
        return u_finish;
    }
    public void setU_finish(String u_finish) {
        this.u_finish = u_finish;
    }
    public String getU_cate() {
        return u_cate;
    }
    public void setU_cate(String u_cate) {
        this.u_cate = u_cate;
    }
}
