package com.example.finalproject;

public class MyPcBean {
    String P_id;
    String P_name;
    String P_phone;
    String P_email;
    String P_sido;
    String P_gugun;
    String P_dong;
    String P_addr;
    String P_holiday;
    String P_picture1;
    String P_picture2;
    String P_picture3;
    String P_pass;
    String SP_p_id;
    String SP_m_id;
    String SP_time;
    String SP_bookmark;
    String ST_m_id;
    String ST_star;

    public MyPcBean() {

    }

    public String getP_id() {
        return P_id;
    }

    public void setP_id(String p_id) {
        P_id = p_id;
    }

    public String getP_name() {
        return P_name;
    }

    public void setP_name(String p_name) {
        P_name = p_name;
    }

    public String getP_phone() {
        return P_phone;
    }

    public void setP_phone(String p_phone) {
        P_phone = p_phone;
    }

    public String getP_email() {
        return P_email;
    }

    public void setP_email(String p_email) {
        P_email = p_email;
    }

    public String getP_sido() {
        return P_sido;
    }

    public void setP_sido(String p_sido) {
        P_sido = p_sido;
    }

    public String getP_gugun() {
        return P_gugun;
    }

    public void setP_gugun(String p_gugun) {
        P_gugun = p_gugun;
    }

    public String getP_dong() {
        return P_dong;
    }

    public void setP_dong(String p_dong) {
        P_dong = p_dong;
    }

    public String getP_addr() {
        return P_addr;
    }

    public void setP_addr(String p_addr) {
        P_addr = p_addr;
    }

    public String getP_holiday() {
        return P_holiday;
    }

    public void setP_holiday(String p_holiday) {
        P_holiday = p_holiday;
    }

    public String getP_picture1() {
        return P_picture1;
    }

    public void setP_picture1(String p_picture1) {
        P_picture1 = p_picture1;
    }

    public String getP_picture2() {
        return P_picture2;
    }

    public void setP_picture2(String p_picture2) {
        P_picture2 = p_picture2;
    }

    public String getP_picture3() {
        return P_picture3;
    }

    public void setP_picture3(String p_picture3) {
        P_picture3 = p_picture3;
    }

    public String getP_pass() {
        return P_pass;
    }

    public void setP_pass(String p_pass) {
        P_pass = p_pass;
    }

    public String getSP_p_id() {
        return SP_p_id;
    }

    public void setSP_p_id(String SP_p_id) {
        this.SP_p_id = SP_p_id;
    }

    public String getSP_m_id() {
        return SP_m_id;
    }

    public void setSP_m_id(String SP_m_id) {
        this.SP_m_id = SP_m_id;
    }

    public String getSP_time() {
        return SP_time;
    }

    public void setSP_time(String SP_time) {
        this.SP_time = SP_time;
    }

    public String getSP_bookmark() {
        return SP_bookmark;
    }

    public void setSP_bookmark(String SP_bookmark) {
        this.SP_bookmark = SP_bookmark;
    }

    public String getST_m_id() {
        return ST_m_id;
    }

    public void setST_m_id(String ST_m_id) {
        this.ST_m_id = ST_m_id;
    }

    public String getST_star() {
        return ST_star;
    }

    public void setST_star(String ST_star) {
        this.ST_star = ST_star;
    }


    public MyPcBean(String P_name) {
        this.P_name = P_name;

    }

}
