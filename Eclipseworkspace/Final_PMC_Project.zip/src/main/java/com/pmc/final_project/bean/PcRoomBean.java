package com.pmc.final_project.bean;

import org.apache.ibatis.type.Alias;

@Alias("pcroom")
public class PcRoomBean {
	
	private String p_id;
	private String p_pass;
	private String p_pass2;
	private String p_name;
	private String p_phone;
	private String p_email;
	private String p_sigungu;
	private String p_dong;
	private String p_addr;
	private String p_holiday;
	private String p_oriName1;
	private String p_sysName1;
	private String p_oriName2;
	private String p_sysName2;
	private String p_oriName3;
	private String p_sysName3;
	public String getP_id() {
		return p_id;
	}
	public void setP_id(String p_id) {
		this.p_id = p_id;
	}
	public String getP_pass() {
		return p_pass;
	}
	public void setP_pass(String p_pass) {
		this.p_pass = p_pass;
	}
	public String getP_pass2() {
		return p_pass2;
	}
	public void setP_pass2(String p_pass2) {
		this.p_pass2 = p_pass2;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_phone() {
		return p_phone;
	}
	public void setP_phone(String p_phone) {
		this.p_phone = p_phone;
	}
	public String getP_email() {
		return p_email;
	}
	public void setP_email(String p_email) {
		this.p_email = p_email;
	}
	public String getP_sigungu() {
		return p_sigungu;
	}
	public void setP_sigungu(String p_sigungu) {
		this.p_sigungu = p_sigungu;
	}
	public String getP_dong() {
		return p_dong;
	}
	public void setP_dong(String p_dong) {
		this.p_dong = p_dong;
	}
	public String getP_addr() {
		return p_addr;
	}
	public void setP_addr(String p_addr) {
		this.p_addr = p_addr;
	}
	public String getP_holiday() {
		return p_holiday;
	}
	public void setP_holiday(String p_holiday) {
		this.p_holiday = p_holiday;
	}
	public String getP_oriName1() {
		return p_oriName1;
	}
	public void setP_oriName1(String p_oriName1) {
		this.p_oriName1 = p_oriName1;
	}
	public String getP_sysName1() {
		return p_sysName1;
	}
	public void setP_sysName1(String p_sysName1) {
		this.p_sysName1 = p_sysName1;
	}
	public String getP_oriName2() {
		return p_oriName2;
	}
	public void setP_oriName2(String p_oriName2) {
		this.p_oriName2 = p_oriName2;
	}
	public String getP_sysName2() {
		return p_sysName2;
	}
	public void setP_sysName2(String p_sysName2) {
		this.p_sysName2 = p_sysName2;
	}
	public String getP_oriName3() {
		return p_oriName3;
	}
	public void setP_oriName3(String p_oriName3) {
		this.p_oriName3 = p_oriName3;
	}
	public String getP_sysName3() {
		return p_sysName3;
	}
	public void setP_sysName3(String p_sysName3) {
		this.p_sysName3 = p_sysName3;
	}
	
	

}
